package ss16.mvc.repository;

import ss16.mvc.model.Student;

public interface IStudentRepository extends IRepository<Student> {


}
