package ss16.mvc.repository;

import ss16.mvc.model.Teacher;

public interface ITeacherRepository extends IRepository<Teacher> {
}
