package ss16.mvc.view;

import ss16.mvc.controller.TeacherController;

public class MainTeacher {
    public static void main(String[] args) {
        TeacherController.menu();
    }
}
