package ss16.mvc.view;

import ss16.mvc.controller.StudentController;

public class MainStudent {
    public static void main(String[] args) {
        StudentController.menu();
    }

}
