package ss16.mvc.service;

public interface IStudentService {
    void addStudent();

    void displayAllStudent();

    void removeStudent();

    void searchStudent();
}
