package ss16.mvc.service;

public interface ITeacherService {
    void addTeacher();

    void searchTeacher();

    void displayTeacher();

    void deleteTeacher();
}
